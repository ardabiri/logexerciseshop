package shopping;

public class Product {
	ProductType producttype;
	String productname;
	int price;
	boolean ForSale;
	Product(String productname,ProductType producttype,int price,boolean ForSale) {
		this.producttype=producttype;
		this.productname=productname;
		this.price=price;
		this.ForSale=ForSale;
	}
	public ProductType getProducttype() {
		return producttype;
	}
	public void setProducttype(ProductType producttype) {
		this.producttype = producttype;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public boolean isForSale() {
		return ForSale;
	}
	public void setForSale(boolean isForSale) {
		this.ForSale = isForSale;
	}
	@Override
	public String toString() {
		return "[productname=" + productname+", producttype=" + producttype  + ", price=" + price
				+ ", ForSale=" + ForSale + "]";
	}
}
