package shopping;

import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class ShopService {
	private static final Logger logger = Logger.getLogger(Logcon.class.getName());
	private static List<Product> products;
	static {
		Product fridge = new Product("fridge",ProductType.HomeStaff,120000,true);
		Product skirt = new Product("skirt",ProductType.Clothes,120000,false);
		Product Microwave = new Product("Microwave",ProductType.HomeStaff,120000,false);
		Product phone = new Product("phone",ProductType.Digital,120000,true);
		Product oven = new Product("oven",ProductType.HomeStaff,120000,false);
		Product flash = new Product("flash",ProductType.Digital,120000,true);
		Product shirt = new Product("shirt",ProductType.Clothes,120000,true);
		Product headphone = new Product("headphone",ProductType.Digital,120000,false);
		
		products = List.of(fridge,oven,phone,flash,shirt,skirt,headphone,Microwave);
	}
	
	public static void PrintList() {
		products.stream()
		.forEach(t->System.out.println(t));	
			
	}
	public static List <Product> DigitalProducts(ProductType pt) throws ProductNotFoundException {
		List <Product> customProduct;
		customProduct = products.stream()
				.filter(t->t.producttype==pt).collect(Collectors.toList());
		
		if( customProduct.size() == 0 ) {
			logger.warning("list empty");
			throw new ProductNotFoundException("The list is empty");}
		return customProduct;
	}
	
	public static void PrintSaleProducts() {
		System.out.println("for sale:");
		products.stream()
				.filter(t->t.isForSale()==true).forEach(t->System.out.println(t));
		
		products.stream()
		.filter(t-> t.productname.equals("Microwave")).forEach(t->System.out.println(t));		
		
	}
}
