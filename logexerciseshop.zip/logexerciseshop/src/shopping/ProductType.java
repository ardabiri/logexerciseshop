package shopping;

public enum ProductType {
	Digital, Clothes, HomeStaff;
}
