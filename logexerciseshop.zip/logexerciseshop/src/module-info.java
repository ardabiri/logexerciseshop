/**
 * 
 */
/**
 * 
 */
module logexerciseshop {
	requires java.logging;
}