package shopping;

public class Main {

	public static void main(String[] args) throws ProductNotFoundException{
		// TODO Auto-generated method stub
		new ShopService();
		ShopService.PrintSaleProducts();
	}

}
